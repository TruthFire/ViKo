﻿using System;

public class Person
{

	public string Name, Surename;
	public DateTime Dob; 


	public Person(string name, string surename, DateTime dob)
	{
		this.Name = name;
		this.Surename = surename;
		this.Dob = dob;
	}

	public DateTime getAge()
    {
		return (DateTime.Now - Dob).ToString("yy");
    }
}
