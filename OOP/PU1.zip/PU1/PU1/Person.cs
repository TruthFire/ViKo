﻿using System;

public class Person
{

	public string Name, Surename;
	public DateTime Dob; 


	public Person(string name, string surename, DateTime dob)
	{
		this.Name = name;
		this.Surename = surename;
		this.Dob = dob;
	}

	public string getAge()
    {
		return DateTime.Now.AddYears(-(Dob.Year+1)).ToString("yy");
	}

	public int yearsToBd()
    {
		DateTime curr = DateTime.Now;
		int year = curr.Month > Dob.Month || curr.Month == Dob.Month && curr.Day > Dob.Day
				  ? curr.Year + 1 : curr.Year;
		var days = (new DateTime(year, Dob.Month, Dob.Day) - curr).TotalDays;
		return (int)days;
	}

	public void printInfo()
    {
		Console.WriteLine("\nVardas:" + Name);
		Console.WriteLine("Pavarde:" + Surename);
		Console.WriteLine("Amžius:" + getAge());
    }
}
