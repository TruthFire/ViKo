﻿using System;

public class Person
{

	private string Name, Surename;
	private DateTime Dob; 


	public Person(string name, string surename, DateTime dob)
	{
		this.Name = name;
		this.Surename = surename;
		this.Dob = dob;
	}

	public string GetAge()
    {
		return DateTime.Now.AddYears(-(Dob.Year+Convert.ToInt32(IsBdBeen()))).ToString("yy");
	}

	public int DaysToBd()
    {
		DateTime curr = DateTime.Now;
		int year = curr.Year + Convert.ToInt32(!IsBdBeen());
		var days = (new DateTime(year, Dob.Month, Dob.Day) - curr).TotalDays;
		return (int)days;
	}
	
	private bool IsBdBeen()
    {
		bool rez = false;
		DateTime curr = DateTime.Now;
		if (curr.Month < Dob.Month || curr.Month == Dob.Month && curr.Day < Dob.Day)
        {
			rez = true;
        }
		return rez;
    }

	public void PrintInfo()
    {
		Console.WriteLine("\nVardas:" + Name);
		Console.WriteLine("Pavarde:" + Surename);
		Console.WriteLine("Amžius:" + GetAge());
    }
}
