﻿using System;

namespace PU1
{
    class Program
    {
        static void Main(string[] args)
        {
            string Name, Surename;
            Console.WriteLine("Jusu vardas:");
            Name = Console.ReadLine();
            Console.WriteLine("Jusu pavarde:");
            Surename = Console.ReadLine();
            Console.WriteLine("Iveskite gimimo diena (pvz.: 2021.11.29:)");
            DateTime dob = DateTime.Parse(Console.ReadLine());
            Console.Clear();
            Person person = new Person(Name, Surename, dob);
            Console.WriteLine("Amžius:" + person.GetAge());
            Console.WriteLine("Dienu iki gimtadienio:" + person.DaysToBd());
            person.PrintInfo();
        }
    }
}
